<?php
echo $jsonString = file_get_contents('settings.json');
?>
